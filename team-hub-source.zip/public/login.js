'use strict';
try{const p=JSON.parse(localStorage.getItem('hub-prefs')||'{}');document.body.classList.toggle('light',p.theme==='light'||p.theme==='system'&&matchMedia('(prefers-color-scheme:light)').matches)}catch{}
const form=document.getElementById('loginForm'),button=document.getElementById('loginSubmit'),message=document.getElementById('loginMessage'),token=document.getElementById('loginToken'),email=document.getElementById('loginEmail'),remember=document.getElementById('loginRemember');
function busy(value,text='Đang xác thực…'){
 button.disabled=value;button.textContent=value?text:'Đăng nhập';email.readOnly=value;token.readOnly=value;remember.disabled=value;
}
function signedIn(data){
 token.value='';
 if(localStorage.getItem('hub-account')!==data.accountId){localStorage.removeItem('hub-subtask-job');localStorage.removeItem('hub-draft')}
 localStorage.setItem('hub-account',data.accountId);location.replace('/');
}
async function signIn(route,body){
 const response=await fetch(route,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
 const data=await response.json();if(!response.ok)throw Object.assign(Error(data.message||'Không đăng nhập được'),{status:response.status});signedIn(data);
}
form.onsubmit=async event=>{
 event.preventDefault();if(button.disabled)return;busy(true);message.textContent='';
 try{await signIn('/api/auth/login',{email:email.value,token:token.value,remember:!document.getElementById('loginRememberRow').hidden&&remember.checked})}
 catch(error){message.textContent=error.message;if([400,401,403].includes(error.status))token.value=''}finally{busy(false)}
};
(async()=>{
 busy(true,'Đang kiểm tra đăng nhập…');
 try{
  const response=await fetch('/api/auth/options');if(!response.ok)return;
  const options=await response.json();document.getElementById('loginRememberRow').hidden=!(options.rememberSupported||options.rememberAvailable);
  if(options.rememberSupported||options.rememberAvailable)document.getElementById('loginPrivacy').textContent='Khi bật ghi nhớ, email và API token được mã hóa bằng kho bảo mật của hệ điều hành trên máy này (Keychain trên macOS). Ghi nhớ không giới hạn ngày, tự khôi phục khi mở app hoặc hết phiên. Nếu không bật, chỉ đăng nhập tạm trong 8 giờ.';
  if(options.message)message.textContent=options.message;
  if(options.canRestore){remember.checked=true;busy(true,'Đang đăng nhập lại…');await signIn('/api/auth/restore',{})}
 }catch(error){message.textContent=error.message||'Chưa khôi phục được đăng nhập. Bạn có thể thử đăng nhập bên dưới.'}
 finally{busy(false)}
})();
