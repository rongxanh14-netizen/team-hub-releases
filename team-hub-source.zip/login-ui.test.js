'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs');
const source=fs.readFileSync(require.resolve('./public/login.js'),'utf8');
async function page(options){
 const elements=Object.fromEntries(['loginForm','loginSubmit','loginMessage','loginToken','loginEmail','loginRemember','loginRememberRow','loginPrivacy'].map(id=>[id,{value:'',hidden:id==='loginRememberRow',checked:false}]));
 const calls=[],stored=new Map();let redirected;
 const context={document:{getElementById:id=>elements[id],body:{classList:{toggle(){}}}},localStorage:{getItem:k=>stored.get(k),setItem:(k,v)=>stored.set(k,v),removeItem:k=>stored.delete(k)},matchMedia:()=>({matches:false}),location:{replace:url=>redirected=url},fetch:async(url,request)=>{calls.push({url,request});return {ok:true,json:async()=>url==='/api/auth/options'?options:{accountId:'test-account'}}}};
 vm.runInNewContext(source,context);await new Promise(resolve=>setImmediate(resolve));
 return {elements,calls,stored,getRedirect:()=>redirected};
}
test('desktop login exposes unchecked remember option and submits only on opt-in',async()=>{
 const p=await page({rememberAvailable:true,canRestore:false});assert.equal(p.elements.loginRememberRow.hidden,false);assert.equal(p.elements.loginRemember.checked,false);
 p.elements.loginEmail.value='test@tepaylink.com.vn';p.elements.loginToken.value='test-token';p.elements.loginRemember.checked=true;
 await p.elements.loginForm.onsubmit({preventDefault(){}});
 assert.equal(JSON.parse(p.calls[1].request.body).remember,true);assert.equal(p.elements.loginToken.value,'');assert.equal(p.getRedirect(),'/');
 assert.equal([...p.stored.values()].includes('test-token'),false);
});
test('opening login restores a saved account without exposing credentials to the page',async()=>{
 const p=await page({rememberAvailable:true,canRestore:true});assert.equal(p.calls[1].url,'/api/auth/restore');assert.equal(p.calls[1].request.body,'{}');assert.equal(p.elements.loginEmail.value,'');assert.equal(p.elements.loginToken.value,'');assert.equal(p.getRedirect(),'/');
});
test('web login retains session-only behavior',async()=>{
 const p=await page({rememberAvailable:false,canRestore:false});assert.equal(p.elements.loginRememberRow.hidden,true);assert.equal(p.calls.length,1);assert.equal(p.elements.loginSubmit.disabled,false);
});
