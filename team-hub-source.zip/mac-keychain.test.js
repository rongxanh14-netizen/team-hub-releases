'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const {createMacKeychainCrypto,runSecurity}=require('./desktop/mac-keychain.cjs');
test('Mac encrypts with a persistent Keychain key, never sends secrets in argv, rejects tampering',async()=>{
 let stored;const calls=[];
 const run=async(args,input)=>{calls.push({args,input});if(args[0]==='find-generic-password'){if(!stored)throw Object.assign(Error('missing'),{code:44});return stored+'\n'}stored=/-w ([a-f0-9]{64})/.exec(input)[1];return ''};
 const c=createMacKeychainCrypto({run}),secret='test-token-only';
 assert.equal(await c.available(),true);assert.equal(calls.length,0);
 const bytes=await c.encrypt(secret);assert.equal(bytes.includes(Buffer.from(secret)),false);
 assert.equal(await createMacKeychainCrypto({run}).decrypt(bytes),secret);
 assert.ok(calls.every(c=>!c.args.includes(stored)&&!c.args.includes(secret)));
 assert.ok(calls.find(c=>c.input).input.includes('-T /usr/bin/security'));
 const bad=Buffer.from(bytes);bad[bad.length-1]^=1;await assert.rejects(c.decrypt(bad));
});
test('locked Keychain never creates a replacement key or falls back to plaintext',async()=>{
 let creates=0;const c=createMacKeychainCrypto({run:async args=>{if(args[0]==='-i')creates++;throw Object.assign(Error('locked'),{code:36})}});
 await assert.rejects(c.encrypt('test-secret'));assert.equal(creates,0);
});
test('legacy encrypted login can be read for authenticated migration',async()=>{
 const c=createMacKeychainCrypto({legacyDecrypt:()=> 'legacy-test-data'});assert.equal(await c.decrypt(Buffer.from('v10legacy')),'legacy-test-data');
});
test('real macOS Keychain round-trip across new process and app storage restart', {skip:process.platform!=='darwin'},async t=>{
 const fs=require('node:fs/promises'),os=require('node:os'),path=require('node:path'),{execFile}=require('node:child_process'),{promisify}=require('node:util');
 const dir=await fs.mkdtemp(path.join(os.tmpdir(),'hub-keychain-test-')),keychain=path.join(dir,'test.keychain-db');
 // A dedicated temporary Keychain only: never alter the runner/user login Keychain.
 await runSecurity(['create-keychain','-p','synthetic-ci-password',keychain]);
 t.after(async()=>{await runSecurity(['delete-keychain',keychain]);await fs.rm(dir,{recursive:true,force:true})});
 await runSecurity(['unlock-keychain','-p','synthetic-ci-password',keychain]);
 const {createCredentialVault}=require('./desktop/credential-vault.cjs');
 const file=path.join(dir,'remembered.bin'),service='vn.tepaylink.teamhub.test.'+Date.now();
 const vault=createCredentialVault({file,crypto:createMacKeychainCrypto({keychain,service})});
 await vault.save({email:'test@tepaylink.com.vn',token:'synthetic-test-token',deviceId:'a'.repeat(64)});
 const script=`const {createCredentialVault}=require('./desktop/credential-vault.cjs');const {createMacKeychainCrypto}=require('./desktop/mac-keychain.cjs');(async()=>{const v=createCredentialVault({file:process.env.TEST_FILE,crypto:createMacKeychainCrypto({keychain:process.env.TEST_KEYCHAIN,service:process.env.TEST_SERVICE}),clock:()=>Date.now()+5*365*86400000});const s=await v.read();if(s.token!=='synthetic-test-token'||s.expires!==null)throw Error('Restore failed');await v.clear();console.log('restored-and-cleared')})().catch(()=>process.exit(1));`;
 const result=await promisify(execFile)(process.execPath,['-e',script],{env:{...process.env,TEST_FILE:file,TEST_KEYCHAIN:keychain,TEST_SERVICE:service}});
 assert.match(result.stdout,/restored-and-cleared/);assert.equal(await fs.stat(file).catch(()=>null),null);
});
