'use strict';
const fs=require('fs/promises'),path=require('path');
const normalize=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/gi,'d').toLowerCase();
const canonical=s=>normalize(s).replace(/\s/g,'').toUpperCase();
const rules=require('./public/label-rules');
const groups=['GAMECONCEPT','WEB-LDP','ALBUM','DAILY','EVENT','ADS','KEY','ADAPT'];
function groupLabels(labels){return [...new Set(rules.normalize(labels).filter(l=>groups.includes(l)))].sort()}
function valid(labels){return rules.valid(labels)}
function plain(node){return typeof node==='string'?node:[node?.text||'',...(node?.content||[]).map(plain)].join(' ')}
function tokens(text){const ignored=new Set(['design','task','thiet','ke','cho','cua','va','the','vui','long','https','com']);return new Set(normalize(text).replace(/\[[^\]]*\]/g,' ').split(/[^a-z0-9]+/).filter(t=>t.length>1&&!/^\d+$/.test(t)&&!ignored.has(t)))}
function overlap(a,b){const union=new Set([...a,...b]);return union.size?[...a].filter(x=>b.has(x)).length/union.size:0}
function suggest(fields,key,samples,base){
  if(base.blockedByRules)return {...base,references:[]};
  const title=tokens(fields.summary),brief=tokens(plain(fields.description));
  const refs=samples.filter(s=>s.status==='approved'&&s.key!==key&&valid(s.labels)).map(s=>{const titleScore=overlap(title,tokens(s.summary));return {key:s.key,summary:s.summary,labels:groupLabels(s.labels).filter(l=>l!=='KEY'),score:Math.round((.85*titleScore+.15*overlap(brief,tokens(s.description)))*100)}}).filter(s=>s.score>=45).sort((a,b)=>b.score-a.score).slice(0,3);
  if(!refs.length)return {...base,references:[]};
  const signature=l=>groupLabels(l).join('|');
  const votes=new Map();for(const ref of refs){const id=signature(ref.labels);const vote=votes.get(id)||{refs:[],weight:0};vote.refs.push(ref);vote.weight+=ref.score;votes.set(id,vote)}
  const ranked=[...votes.values()].sort((a,b)=>b.weight-a.weight),agreed=ranked[0].refs;
  const unanimous=ranked.length===1,strongMajority=agreed.length>=2&&agreed.every(r=>r.score>=70)&&ranked[0].weight/refs.reduce((sum,r)=>sum+r.score,0)>=.65;
  const closest=refs[0],other=refs.find(r=>signature(r.labels)!==signature(closest.labels));
  const clearClosest=closest.score>=85&&(!other||closest.score-other.score>=15)&&signature(agreed[0].labels)===signature(closest.labels);
  const sufficient=unanimous?(agreed.length>=2||agreed[0].score>=85):(strongMajority||clearClosest);
  if(base.labels.length)return {...base,references:refs,reasons:[...base.reasons,'Tham chiếu mẫu đã duyệt; quy tắc được ưu tiên khi mẫu khác đề xuất.']};
  if(!sufficient)return {...base,references:refs,reasons:[...base.reasons,'Mẫu tương tự chưa đủ mạnh hoặc không thống nhất; cần duyệt thủ công.']};
  const labels=agreed[0].labels.map(l=>l==='ADS'?'Ads':l),existing=fields.labels||[];
  const conflict=groupLabels(existing).some(l=>!agreed[0].labels.includes(l));
  const additions=labels.filter(l=>!existing.some(e=>canonical(e)===canonical(l)));
  return {labels,additions:conflict?[]:additions,eligible:!conflict&&!!additions.length,status:conflict?'review':additions.length?'ready':'unchanged',references:refs,reasons:['Đề xuất từ mẫu đã duyệt: '+agreed.map(r=>r.key).join(', ')+(unanimous?'':' · Nhóm mẫu tương đồng cao chiếm đa số; các mẫu khác nhãn không được dùng để gán.'),'Độ tương tự văn bản, không phải xác suất đúng. Không sao chép KEY từ mẫu.',...(conflict?['Nhãn hiện tại khác đề xuất; cần kiểm tra thủ công.']:[])]};
}
function createStore(file=path.join(require('./runtime-paths').dataDir,'label-samples.json')){
  let queue=Promise.resolve();
  async function list(){await queue;try{return JSON.parse(await fs.readFile(file,'utf8')).samples.map(s=>s.status==='approved'&&!valid(s.labels)?{...s,status:'pending'}:s)}catch(e){if(e.code==='ENOENT')return [];throw e}}
  function mutate(fn){const work=queue.then(async()=>{let samples;try{samples=JSON.parse(await fs.readFile(file,'utf8')).samples}catch(e){if(e.code!=='ENOENT')throw e;samples=[]}const result=fn(samples);await fs.mkdir(path.dirname(file),{recursive:true});await fs.writeFile(file+'.tmp',JSON.stringify({version:1,samples},null,2));await fs.rename(file+'.tmp',file);return result});queue=work.catch(()=>{});return work}
  function ingest(issues,approved=false,trustedHistory=false,force=false){return mutate(samples=>{let added=0;for(const {key,fields} of issues){const labels=fields.labels||[];const index=samples.findIndex(s=>s.key===key),old=samples[index];if(!groupLabels(labels).length&&!old)continue;const sourceTag=JSON.stringify([fields.summary,plain(fields.description).slice(0,20000),labels]);const record={key,sourceTag,summary:fields.summary,description:plain(fields.description).slice(0,20000),labels,assignee:fields.assignee?.displayName||'',trustedHistory,status:approved&&valid(labels)?'approved':'pending',updatedAt:new Date().toISOString()};if(!force&&old&&old.sourceTag===sourceTag&&(!approved||trustedHistory))continue;if(index>=0)samples[index]=record;else samples.push(record);added++}return added})}
  function review(key,action,labels){return mutate(samples=>{const s=samples.find(s=>s.key===key);if(!s)throw Error('Không tìm thấy mẫu');if(action==='approve'){const chosen=labels||s.labels;if(!Array.isArray(chosen)||chosen.some(l=>typeof l!=='string'||!groups.includes(canonical(l))&&canonical(l)!=='KEY')||!valid(chosen))throw Error(rules.message);s.labels=chosen;s.status='approved'}else if(action==='reject')s.status='rejected';else throw Error('Thao tác không hợp lệ');s.updatedAt=new Date().toISOString();return s})}
  function approveHistory(){return mutate(samples=>{let count=0;for(const s of samples){if(s.status!=='rejected'&&valid(s.labels)){s.status='approved';s.trustedHistory=true;s.updatedAt=new Date().toISOString();count++}}return count})}
  return {list,ingest,review,approveHistory};
}
module.exports={createStore,suggest,valid};
