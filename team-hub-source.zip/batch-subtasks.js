'use strict';
const fs=require('fs/promises'),path=require('path'),{randomUUID,createHash}=require('crypto');
const {dataDir}=require('./runtime-paths');
const LABELS=['Ads','ALBUM','DAILY','KEY','GAMECONCEPT','EVENT','WEB-LDP','ADAPT'];
function sheetExportUrl(value){
 let u;try{u=new URL(String(value||''))}catch{throw Error('Dán link Google Sheets hợp lệ')}
 const match=u.pathname.match(/^\/spreadsheets\/d\/([a-zA-Z0-9_-]+)(?:\/|$)/);
 if(u.protocol!=='https:'||u.hostname!=='docs.google.com'||u.port||u.username||u.password||!match)throw Error('Chỉ nhận link https://docs.google.com/spreadsheets/d/...');
 return 'https://docs.google.com/spreadsheets/d/'+match[1]+'/export?format=xlsx';
}
async function importGoogleSheet(link,fetcher=fetch,parser=parseWorkbook){
 let url=sheetExportUrl(link);const signal=AbortSignal.timeout(30000);
 for(let i=0;i<5;i++){
  const r=await fetcher(url,{redirect:'manual',signal});
  if([301,302,303,307,308].includes(r.status)){
   const location=r.headers.get('location');if(!location)throw Error('Google Sheets không trả về file');
   const next=new URL(location,url);
   if(next.protocol!=='https:'||next.port||next.username||next.password||!(next.hostname==='docs.google.com'||next.hostname==='googleusercontent.com'||next.hostname.endsWith('.googleusercontent.com')))throw Error('Sheet chưa cho phép xem bằng link. Bật “Bất kỳ ai có đường liên kết – Người xem” hoặc tải file .xlsx lên.');
   url=next.href;continue;
  }
  if(!r.ok)throw Error('Không đọc được Sheet. Kiểm tra link và quyền “Bất kỳ ai có đường liên kết – Người xem”, hoặc tải file .xlsx lên.');
  if(Number(r.headers.get('content-length'))>5*1024*1024)throw Error('File tối đa 5 MB');
  let size=0;const chunks=[];for await(const chunk of r.body){size+=chunk.length;if(size>5*1024*1024)throw Error('File tối đa 5 MB');chunks.push(Buffer.from(chunk))}
  const buffer=Buffer.concat(chunks);if(buffer[0]!==0x50||buffer[1]!==0x4b)throw Error('Sheet chưa cho phép tải dữ liệu. Kiểm tra quyền chia sẻ hoặc dùng file .xlsx.');
  return parser(buffer);
 }
 throw Error('Google Sheets chuyển hướng quá nhiều. Hãy tải file .xlsx lên.');
}
function validateRows(rows){
 if(!Array.isArray(rows)||!rows.length||rows.length>100)throw Error('File cần có từ 1 đến 100 subtask');
 let imageBytes=0;
 return rows.map((r,i)=>{const errors=[...(Array.isArray(r.errors)?r.errors:[])],summary=String(r.summary||'').trim(),description=String(r.description||'').trim(),duedate=String(r.duedate||'').trim();
 const labels=[...new Set(String(r.labels||'').split(/[,;\n]/).map(x=>x.trim()).filter(Boolean).map(x=>LABELS.find(l=>l.toLowerCase()===x.toLowerCase())||x))];
 if(!summary||summary.length>255)errors.push('Tên task bắt buộc, tối đa 255 ký tự');
 if(description.length>10000)errors.push('Mô tả tối đa 10.000 ký tự');
 if(labels.some(l=>!LABELS.includes(l)))errors.push('Nhãn không hợp lệ: '+labels.filter(l=>!LABELS.includes(l)).join(', '));
 if(duedate&&(!/^\d{4}-\d{2}-\d{2}$/.test(duedate)||!Number.isFinite(Date.parse(duedate+'T00:00:00Z'))||new Date(duedate+'T00:00:00Z').toISOString().slice(0,10)!==duedate))errors.push('DueDate dùng ngày Excel hoặc YYYY-MM-DD');
 const images=[];
 if(r.images!==undefined&&!Array.isArray(r.images))errors.push('Danh sách ảnh không hợp lệ');
 if((r.images||[]).length>3)errors.push('Tối đa 3 ảnh mỗi task');
 for(const image of (Array.isArray(r.images)?r.images:[]).slice(0,3)){
  const match=/^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+/]+={0,2})$/.exec(String(image?.dataUrl||''));
  if(!match){errors.push('Ảnh phải là PNG/JPG/WebP');continue;}
  const bytes=Buffer.from(match[2],'base64');imageBytes+=bytes.length;
  const magic=match[1]==='png'?bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])):match[1]==='jpeg'?bytes[0]===255&&bytes[1]===216&&bytes[2]===255:bytes.toString('ascii',0,4)==='RIFF'&&bytes.toString('ascii',8,12)==='WEBP';
  if(!magic||bytes.length>2*1024*1024){errors.push('Ảnh không hợp lệ hoặc vượt 2 MB');continue;}
  images.push({name:String(image.name||'image.'+match[1]).replace(/[^\p{L}\p{N}._ -]/gu,'_').slice(0,120),dataUrl:image.dataUrl});
 }
 if(imageBytes>10*1024*1024)errors.push('Tổng ảnh toàn bảng tối đa 10 MB');
 return {row:r.row||i+2,summary,description,labels,duedate,images,errors};});
}
async function attachImages(jira,row){
 if(!row.images?.length)return;
 row.attachments=[];
 try{
  for(const image of row.images){const [prefix,base64]=image.dataUrl.split(','),mime=prefix.slice(5).split(';')[0],form=new FormData();form.append('file',new Blob([Buffer.from(base64,'base64')],{type:mime}),image.name);const uploaded=await jira('/rest/api/3/issue/'+encodeURIComponent(row.key)+'/attachments',{method:'POST',body:form});
   const file=uploaded[0];if(!file?.id)throw Error('Jira chưa xác nhận ảnh đính kèm');row.attachments.push({id:file.id,name:file.filename||image.name,url:'https://tpl-vn.atlassian.net/rest/api/3/attachment/content/'+encodeURIComponent(file.id)});
  }
  const description=adf(row.description);for(const file of row.attachments)description.content.push({type:'paragraph',content:[{type:'text',text:'Ảnh: '+file.name,marks:[{type:'link',attrs:{href:file.url}}]}]});
  await jira('/rest/api/3/issue/'+encodeURIComponent(row.key),{method:'PUT',body:JSON.stringify({fields:{description}})});
 }catch(e){row.imageWarning='Task đã tạo, nhưng ảnh/mô tả chưa hoàn tất: '+e.message+'. Mở task để kiểm tra; không tạo lại task.';}
}
const adf=text=>({type:'doc',version:1,content:text.split(/\r?\n/).map(line=>({type:'paragraph',content:line?[{type:'text',text:line}]:[]}))});
async function parseWorkbook(buffer){return validateRows(await require('./workbook-reader').readWorkbook(buffer));}
function register(app,jira,wrap,express){
 const dir=path.join(dataDir,'subtask-jobs'),running=new Set();
 const notifyJobs=()=>process.parentPort?.postMessage({type:'busy',scope:'jobs',count:running.size});
 const save=async job=>{await fs.mkdir(dir,{recursive:true});const file=path.join(dir,job.id+'.json');await fs.writeFile(file+'.tmp',JSON.stringify(job));for(let attempt=0;;attempt++){try{await fs.rename(file+'.tmp',file);break}catch(e){if(!['EPERM','EACCES','EBUSY'].includes(e.code)||attempt>=8)throw e;await new Promise(resolve=>setTimeout(resolve,25*(attempt+1)));}}};
 const read=async (id,accountId)=>{if(!/^[0-9a-f-]{36}$/.test(id))throw Error('Mã phiên không hợp lệ');const job=JSON.parse(await fs.readFile(path.join(dir,id+'.json'),'utf8'));if(job.owner!==accountId)throw Error('Phiên tạo không thuộc tài khoản đang đăng nhập');return job};
 const checkProject=p=>{if(!['MTG','MC'].includes(p))throw Error('Chọn workspace MTG hoặc MC')};
 const getTypes=async project=>{const d=await jira('/rest/api/3/issue/createmeta/'+project+'/issuetypes?maxResults=100');return d.issueTypes||d.values||[]};
 app.post('/api/subtasks/upload',express.raw({type:'application/octet-stream',limit:'5mb'}),wrap(async(req,res)=>{if(!Buffer.isBuffer(req.body))throw Error('Hãy chọn file .xlsx');res.json({rows:await parseWorkbook(req.body)})}));
 app.post('/api/subtasks/google-sheet',wrap(async(req,res)=>{res.json({rows:await importGoogleSheet(req.body.url)})}));
 app.get('/api/subtasks/assignees',wrap(async(req,res)=>{const project=String(req.query.project||'');checkProject(project);const users=await jira('/rest/api/3/user/assignable/search?project='+project+'&maxResults=1000');res.json({users:users.filter(u=>u.active!==false).map(u=>({id:u.accountId,name:u.displayName}))})}));
 app.get('/api/subtasks/options',wrap(async(req,res)=>{
  const project=String(req.query.project||'');checkProject(project);const epic=String(req.query.epic||'');if(epic&&!new RegExp('^'+project+'-\\d+$').test(epic))throw Error('Epic khác workspace');
  const kind=req.query.kind==='parents'?'parents':'epics';
  let jql=kind==='epics'?`project = ${project} AND issuetype = Epic ORDER BY updated DESC`:`project = ${project} AND parent = "${epic}" AND issuetype not in subTaskIssueTypes() AND issuetype != Epic ORDER BY updated DESC`;
  if(kind==='parents'&&!epic)return res.json({items:[],more:false});
  const d=await jira('/rest/api/3/search/jql',{method:'POST',body:JSON.stringify({jql,fields:['summary','issuetype','parent','project'],maxResults:100,...(req.query.cursor?{nextPageToken:String(req.query.cursor)}:{})})});
  res.json({items:d.issues.map(i=>({key:i.key,summary:i.fields.summary})),cursor:d.isLast?null:d.nextPageToken||null});
 }));
 app.post('/api/subtasks/prepare',wrap(async(req,res)=>{
  const {project,epic,parentKey,newParent}=req.body;checkProject(project);
  if(!new RegExp('^'+project+'-\\d+$').test(epic||''))throw Error('Chọn Epic hợp lệ');
  const epicIssue=await jira('/rest/api/3/issue/'+epic+'?fields=issuetype,project');
  if(epicIssue.fields.project.key!==project||!(epicIssue.fields.issuetype.hierarchyLevel===1||epicIssue.fields.issuetype.name==='Epic'))throw Error('Epic không hợp lệ');
  const rows=validateRows(req.body.rows);if(rows.some(r=>r.errors.length))return res.status(400).json({message:'File còn dòng lỗi, hãy sửa rồi tải lại',rows});
  const types=await getTypes(project),subtype=types.find(t=>t.subtask||t.hierarchyLevel===-1||/^sub.?task$/i.test(t.name)),parentType=types.find(t=>!t.subtask&&/^task$/i.test(t.name));
  if(!subtype)throw Error('Workspace chưa cho phép tạo Subtask');
  let parent;
  if(newParent){if(!newParent.summary?.trim()||newParent.summary.length>255||!parentType)throw Error('Nhập tên task lớn (tối đa 255 ký tự)');if(String(newParent.description||'').length>10000)throw Error('Mô tả task lớn quá dài');parent={summary:newParent.summary.trim(),description:String(newParent.description||''),type:parentType.id}}
  else{if(!new RegExp('^'+project+'-\\d+$').test(parentKey||''))throw Error('Chọn task lớn');const d=await jira('/rest/api/3/issue/'+parentKey+'?fields=issuetype,parent,project,summary');if(d.fields.project.key!==project||d.fields.issuetype.subtask||d.fields.issuetype.hierarchyLevel===1||d.fields.parent?.key!==epic)throw Error('Task lớn không thuộc Epic/workspace đã chọn');parent={key:parentKey,summary:d.fields.summary}}
  let assignee=null;
  if(req.body.assignee){if(typeof req.body.assignee!=='string'||req.body.assignee.length>200)throw Error('Người thực hiện không hợp lệ');const users=await jira('/rest/api/3/user/assignable/search?project='+project+'&accountId='+encodeURIComponent(req.body.assignee)+'&maxResults=100');const user=users.find(u=>u.accountId===req.body.assignee&&u.active!==false);if(!user)throw Error('Người thực hiện không thể nhận task trong workspace này');assignee={id:user.accountId,name:user.displayName}}
  const job={assignee,owner:req.accountId,id:randomUUID(),createdAt:new Date().toISOString(),project,epic,parent,subtype:subtype.id,status:'preview',rows:rows.map(r=>({...r,status:'waiting'}))};await save(job);res.json(job);
 }));
 async function run(job){
  try{
   if(!job.parent.key){job.parent.status='sending';await save(job);try{const d=await jira('/rest/api/3/issue',{method:'POST',body:JSON.stringify({fields:{project:{key:job.project},issuetype:{id:job.parent.type},parent:{key:job.epic},summary:job.parent.summary,...(job.parent.description?{description:adf(job.parent.description)}:{})}})});job.parent.key=d.key;job.parent.status='created';await save(job)}catch(e){job.parent.status=/^Jira 4\d\d:/.test(e.message)?'failed':'unknown';job.parent.error=e.message;job.status='stopped';await save(job);return}}
   for(const row of job.rows){if(row.status!=='waiting')continue;row.status='sending';await save(job);try{const d=await jira('/rest/api/3/issue',{method:'POST',body:JSON.stringify({fields:{project:{key:job.project},issuetype:{id:job.subtype},parent:{key:job.parent.key},summary:row.summary,labels:row.labels,...(job.assignee?{assignee:{accountId:job.assignee.id}}:{}),...(row.duedate?{duedate:row.duedate}:{}),...(row.description?{description:adf(row.description)}:{})}})});row.key=d.key;row.status='created';await save(job);await attachImages(jira,row)}catch(e){row.error=e.message;row.status=/^Jira 4\d\d:/.test(e.message)?'failed':'unknown'}await save(job);if(row.status==='unknown'){job.status='stopped';await save(job);return}}
   job.status=job.rows.every(r=>r.status==='created'&&!r.imageWarning)?'completed':'partial';await save(job);
  }catch(e){job.status='stopped';job.error='Phiên tạo đã dừng: '+e.message;try{await save(job)}catch{}}
  finally{running.delete(job.id);notifyJobs()}
 }
 app.post('/api/subtasks/jobs/:id/start',wrap(async(req,res)=>{const job=await read(req.params.id,req.accountId);if(job.status!=='preview')return res.json(job);if(running.has(job.id))return res.json(job);running.add(job.id);notifyJobs();job.status='running';try{await save(job)}catch(e){running.delete(job.id);notifyJobs();throw e}res.json(job);void run(job)}));
 app.get('/api/subtasks/jobs/:id',wrap(async(req,res)=>{let job=await read(req.params.id,req.accountId);if(job.status==='running'&&!running.has(job.id)){job=await read(req.params.id,req.accountId);if(job.status!=='running')return res.json(job);job.status='stopped';job.error='Server đã khởi động lại. Kiểm tra các dòng đang gửi trên Jira trước khi tạo lại.';for(const row of job.rows)if(row.status==='sending')row.status='unknown';if(job.parent.status==='sending')job.parent.status='unknown';await save(job)}res.json(job)}));
}
module.exports={register,validateRows,adf,parseWorkbook,sheetExportUrl,importGoogleSheet,attachImages};
