'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs');
const source=fs.readFileSync(require.resolve('./public/app.js'),'utf8').split("window.addEventListener('storage'")[0];
test('expired session restores once for simultaneous calls and retries without losing the page',async()=>{
 let restores=0,valid=false,redirect=false;
 const fetch=async url=>{if(url==='/api/auth/restore'){restores++;await new Promise(r=>setTimeout(r,5));valid=true;return new Response('{}')}return valid?new Response('{}'):new Response(JSON.stringify({code:'AUTH_SESSION_EXPIRED'}),{status:401})};
 const ctx={window:{fetch},location:{replace:()=>redirect=true}};vm.runInNewContext(source,ctx);
 const results=await Promise.all([ctx.window.fetch('/api/tasks'),ctx.window.fetch('/api/connection')]);
 assert.equal(restores,1);assert.ok(results.every(r=>r.ok));assert.equal(redirect,false);
});
test('temporary restore failure keeps page and credentials; invalid login redirects',async()=>{
 for(const status of [502,401]){
  let redirected=false;
  const ctx={window:{fetch:async url=>url==='/api/auth/restore'?new Response('{}',{status}):new Response(JSON.stringify({code:'AUTH_SESSION_EXPIRED'}),{status:401})},location:{replace:()=>redirected=true}};
  vm.runInNewContext(source,ctx);assert.equal((await ctx.window.fetch('/api/tasks')).status,status);assert.equal(redirected,status===401);
 }
});
