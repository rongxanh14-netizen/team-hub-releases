'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs/promises'),path=require('node:path'),os=require('node:os');
const {randomBytes,createCipheriv,createDecipheriv}=require('node:crypto');
const {createCredentialVault}=require('./desktop/credential-vault.cjs');
const auth=require('./account-auth');
const email='remember-test@tepaylink.com.vn',token='synthetic-token-for-tests-only',desktopKey='test-desktop-secret';
let number=0;
async function fixture(t){
 const dir=await fs.mkdtemp(path.join(os.tmpdir(),'team-hub-remember-'));t.after(()=>fs.rm(dir,{recursive:true,force:true}));
 const key=randomBytes(32),file=path.join(dir,'login.bin');let now=Date.now(),enabled=true;
 const crypto={available:async()=>enabled,encrypt:async value=>{const iv=randomBytes(12),cipher=createCipheriv('aes-256-gcm',key,iv),data=Buffer.concat([cipher.update(value,'utf8'),cipher.final()]);return Buffer.concat([iv,cipher.getAuthTag(),data]);},decrypt:async value=>{const cipher=createDecipheriv('aes-256-gcm',key,value.subarray(0,12));cipher.setAuthTag(value.subarray(12,28));return Buffer.concat([cipher.update(value.subarray(28)),cipher.final()]).toString('utf8');}};
 const makeVault=()=>createCredentialVault({file,crypto,clock:()=>now});
 const vault=makeVault(),handlers={},ip='remember-test-'+(++number);
 const mount=selected=>auth.install({get:(p,h)=>handlers[p]=h,post:(p,h)=>handlers[p]=h,use:(p,h)=>handlers[p]=h},{vault:selected,desktopKey});mount(vault);
 const call=async(route,{body={},cookie='',trusted=true}={})=>{
  let status=200,data;const headers={};
  const req={body,ip,headers:{cookie,...(trusted?{'x-team-hub-desktop':desktopKey}:{})}};
  const res={status(n){status=n;return this},json(d){data=d;return this},setHeader(k,v){headers[k]=v}};
  await handlers[route](req,res,()=>{data={accountId:auth.owner()}});return {status,data,headers};
 };
 let jiraStatus=200;
 const original=global.fetch;global.fetch=async url=>new Response(JSON.stringify(url.endsWith('/myself')?{accountId:'verified-test-account',emailAddress:email,active:true}:{}),{status:jiraStatus});t.after(()=>global.fetch=original);
 return {file,vault,call,restart:()=>mount(makeVault()),advance:ms=>now+=ms,setAvailable:value=>enabled=value,setJiraStatus:value=>jiraStatus=value};
}
function cookies(result){return [].concat(result.headers['Set-Cookie']||[]).map(c=>c.split(';')[0]).join('; ');}
function rememberCookie(result){return cookies(result).split('; ').find(c=>c.startsWith('hub_remember='));}
test('remember login is opt-in, app-only and never returns API tokens',async t=>{
 const f=await fixture(t);
 assert.equal((await f.call('/api/auth/options',{trusted:false})).data.rememberAvailable,false);
 const regular=await f.call('/api/auth/login',{body:{email,token}});
 assert.equal(regular.status,200);assert.equal(regular.data.remembered,false);assert.equal(await fs.stat(f.file).catch(()=>null),null);
 const denied=await f.call('/api/auth/login',{trusted:false,body:{email,token,remember:true}});
 assert.equal(denied.status,400);assert.equal(await fs.stat(f.file).catch(()=>null),null);
 const saved=await f.call('/api/auth/login',{body:{email,token,remember:true}});
 assert.equal(saved.status,200);assert.equal(saved.data.remembered,true);
 assert.equal(JSON.stringify(saved).includes(token),false);
 assert.equal((await fs.readFile(f.file)).includes(Buffer.from(token)),false);
 assert.match(saved.headers['Set-Cookie'][1],/HttpOnly; SameSite=Strict; Path=\/; Max-Age=2592000/);
});
test('fresh vault restores the verified account with a bound cookie; browsers cannot restore',async t=>{
 const f=await fixture(t),saved=await f.call('/api/auth/login',{body:{email,token,remember:true}}),cookie=rememberCookie(saved);
 f.restart();
 assert.equal((await f.call('/api/auth/options',{cookie})).data.canRestore,true);
 assert.equal((await f.call('/api/auth/restore',{cookie,trusted:false})).status,401);
 assert.equal((await f.call('/api/auth/restore',{cookie:'hub_remember='+'a'.repeat(64)})).status,401);
 const restored=await f.call('/api/auth/restore',{cookie});assert.equal(restored.status,200);assert.equal(restored.data.remembered,true);
 assert.equal((await f.call('/api',{cookie:cookies(restored)})).data.accountId,'verified-test-account');
 assert.equal(JSON.stringify(restored).includes(token),false);
});
test('logout deletes saved credentials, revokes the session and clears both cookies',async t=>{
 const f=await fixture(t),saved=await f.call('/api/auth/login',{body:{email,token,remember:true}}),cookie=cookies(saved);
 const result=await f.call('/api/auth/logout',{cookie});assert.equal(result.status,200);
 assert.equal(await fs.stat(f.file).catch(()=>null),null);
 assert.equal(result.headers['Set-Cookie'].length,2);assert.ok(result.headers['Set-Cookie'].every(c=>c.endsWith('Max-Age=0')));
 assert.equal((await f.call('/api',{cookie})).status,401);
 assert.equal((await f.call('/api/auth/options',{cookie})).data.canRestore,false);
});
test('logging in without remember removes an earlier saved login',async t=>{
 const f=await fixture(t),saved=await f.call('/api/auth/login',{body:{email,token,remember:true}});
 const result=await f.call('/api/auth/login',{cookie:cookies(saved),body:{email,token,remember:false}});
 assert.equal(result.status,200);assert.equal(result.data.remembered,false);assert.equal(await fs.stat(f.file).catch(()=>null),null);
});
test('temporary Jira errors preserve saved login; revoked tokens remove it',async t=>{
 const f=await fixture(t),saved=await f.call('/api/auth/login',{body:{email,token,remember:true}}),cookie=rememberCookie(saved);
 f.setJiraStatus(503);assert.equal((await f.call('/api/auth/restore',{cookie})).status,502);assert.equal((await f.call('/api/auth/options',{cookie})).data.canRestore,true);
 f.setJiraStatus(401);assert.equal((await f.call('/api/auth/restore',{cookie})).status,401);assert.equal(await fs.stat(f.file).catch(()=>null),null);
});
test('expiry after 30 days rejects restore and expired data can still be deleted',async t=>{
 const f=await fixture(t),deviceId='b'.repeat(64);await f.vault.save({email,token,deviceId});
 f.advance(30*86400000+1);assert.equal(await f.vault.read(deviceId),null);assert.equal(await f.vault.has(deviceId),false);
 await f.vault.clear(deviceId);assert.equal(await fs.stat(f.file).catch(()=>null),null);
});
test('encryption unavailable never falls back to plaintext; logout can still remove the encrypted file',async t=>{
 const f=await fixture(t);f.setAvailable(false);
 assert.equal((await f.call('/api/auth/options')).data.rememberAvailable,false);
 await assert.rejects(f.vault.save({email,token,deviceId:'c'.repeat(64)}));assert.equal(await fs.stat(f.file).catch(()=>null),null);
 f.setAvailable(true);const saved=await f.call('/api/auth/login',{body:{email,token,remember:true}});f.setAvailable(false);
 assert.equal((await f.call('/api/auth/logout',{cookie:cookies(saved)})).status,200);assert.equal(await fs.stat(f.file).catch(()=>null),null);
});
test('desktop logout removes an orphaned save even if the remember cookie was reset',async t=>{
 const f=await fixture(t);const saved=await f.call('/api/auth/login',{body:{email,token,remember:true}});assert.equal(saved.status,200);
 assert.equal((await f.call('/api/auth/logout')).status,200);assert.equal(await fs.stat(f.file).catch(()=>null),null);
});
test('failed credential deletion reports failure and keeps the session available to retry logout',async t=>{
 const f=await fixture(t),saved=await f.call('/api/auth/login',{body:{email,token,remember:true}});
 f.vault.clear=async()=>{throw Error('Synthetic file access failure')};
 const result=await f.call('/api/auth/logout',{cookie:cookies(saved)});assert.equal(result.status,503);assert.equal(result.headers['Set-Cookie'],undefined);
 assert.equal((await f.call('/api',{cookie:cookies(saved)})).status,200);
});
test('corrupt saved data cannot authenticate and can be removed on logout',async t=>{
 const f=await fixture(t);await fs.writeFile(f.file,'corrupted');assert.equal(await f.vault.has('d'.repeat(64)),false);
 await f.vault.clear('d'.repeat(64));assert.equal(await fs.stat(f.file).catch(()=>null),null);
});
