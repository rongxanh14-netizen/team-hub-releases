const {test}=require('node:test'),assert=require('node:assert/strict');
const auth=require('./account-auth');
test('separate verified Jira sessions, protect APIs, reject outsider and revoke logout',async()=>{
 const handlers={};auth.install({get:(p,h)=>handlers[p]=h,post:(p,h)=>handlers[p]=h,use:(p,h)=>handlers[p]=h});
 const original=global.fetch;
 global.fetch=async(url,opts)=>{const email=Buffer.from(opts.headers.Authorization.slice(6),'base64').toString().split(':')[0];return new Response(JSON.stringify(url.endsWith('/myself')?{accountId:email,emailAddress:email,active:true}:{}),{status:200})};
 const call=async(path,body={},cookie='')=>{let data,status=200,headers={};const res={status(n){status=n;return this},json(d){data=d},setHeader(k,v){headers[k]=v}};await handlers[path]({body,headers:{cookie},ip:'test'},res);return {data,status,headers}};
 try{
  assert.equal((await call('/api')).status,401);
  assert.equal((await call('/api/auth/login',{email:'external@example.com',token:'fake'})).status,400);
  const a=await call('/api/auth/login',{email:'a@tepaylink.com.vn',token:'fake-a'}),b=await call('/api/auth/login',{email:'b@tepaylink.com.vn',token:'fake-b'});
  assert.equal(a.status,200);assert.equal(b.status,200);assert.match(a.headers['Set-Cookie'],/HttpOnly; SameSite=Strict/);
  const cache=new auth.AccountMap();
  for(const [session,expected]of [[a,'a@tepaylink.com.vn'],[b,'b@tepaylink.com.vn']])await new Promise((resolve,reject)=>handlers['/api']({headers:{cookie:session.headers['Set-Cookie']}},{status(){throw Error('Unexpected rejection')}},()=>{try{assert.equal(auth.owner(),expected);assert.equal(cache.get('task'),undefined);cache.set('task',expected);resolve()}catch(e){reject(e)}}));
  await call('/api/auth/logout',{},a.headers['Set-Cookie']);assert.equal((await call('/api',{},a.headers['Set-Cookie'])).status,401);
  assert.equal(JSON.stringify(a.data).includes('fake-a'),false);
 }finally{global.fetch=original}
});
