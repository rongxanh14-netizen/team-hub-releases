'use strict';
const {randomUUID,createHash}=require('crypto');
const {createStore,suggest}=require('./label-learning');
const rules=require('./public/label-rules');
const SOURCE='';
const DESIGN={has:id=>require('./team-config').read().teams.Design.some(([member])=>member===id)};
const normalize=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/gi,'d').toLowerCase();
const labelKey=s=>normalize(s).replace(/\s/g,'').toUpperCase();
const GROUPS=['GAMECONCEPT','WEB-LDP','ALBUM','DAILY','EVENT','ADS','KEY','ADAPT'];
function textOf(node){if(typeof node==='string')return node;if(!node)return '';return [node.text||'',...(node.content||[]).map(textOf)].join(' ')}
function classify(fields){
  const title=normalize(fields.summary),brief=normalize(textOf(fields.description));
  const patterns={GAMECONCEPT:/\b(logo game|icon game|storekit|brandkit|rebranding|nhan dien game|game ?concept)\b/,'WEB-LDP':/\b(website|landing ?page|web[- ]?ldp|ldp|trang web|trang chu|hero banner)\b/,ALBUM:/\b(album|bo anh)\b/,EVENT:/\b(event|su kien|sinh nhat|alpha ?test|open beta|launching|may chu moi|ra mat|khai mo)\b/,ADS:/\b(ads|quang cao tra phi|chay quang cao|app install|user acquisition|ua)\b/,DAILY:/\b(daily|hang ngay|thuong nhat|thong bao thong thuong|dinh ky)\b/};
  let hits=Object.entries(patterns).filter(([,re])=>re.test(title)).map(([name])=>name);
  let evidence='Tiêu đề';
  if(!hits.length){hits=Object.entries(patterns).filter(([,re])=>re.test(brief)).map(([name])=>name);evidence='Mô tả';}
  const reasons=[],labels=[];
  const adapt=/\b(adapt|resize|chinh sua tu mau|dieu chinh tu mau)\b/.test(title);
  const key=/\b(key|kv|master|layout mau)\b/.test(title);
  if(adapt)hits.push('ADAPT');
  const dependencies=(fields.issuelinks||[]).some(l=>l.outwardIssue&&/^blocks$/i.test(l.type?.outward||''));
  if(key||dependencies)hits.push('KEY');
  hits=[...new Set(hits)];
  if(rules.valid(hits)){labels.push(...hits.map(x=>x==='ADS'?'Ads':x));reasons.push(evidence+' phù hợp '+labels.join(' + '));}
  else reasons.push(hits.length?'Tổ hợp tín hiệu chưa hợp lệ: '+hits.join(', ')+'. '+rules.message:'Chưa đủ thông tin để xác định nhóm công việc');
  const existing=fields.labels||[],oldGroups=existing.map(labelKey).filter(l=>GROUPS.includes(l));
  const proposedGroups=labels.map(labelKey).filter(l=>GROUPS.includes(l));
  const conflict=oldGroups.some(l=>!proposedGroups.includes(l));
  if(conflict)reasons.push('Nhãn nhóm hiện tại khác đề xuất; cần kiểm tra thủ công');
  const additions=labels.filter(l=>!existing.some(old=>labelKey(old)===labelKey(l)));
  const eligible=rules.valid([...existing,...labels])&&!conflict&&additions.length>0;
  return {labels,additions:eligible?additions:[],reasons,eligible,blockedByRules:hits.length>0&&!rules.valid(hits),status:conflict||!labels.length?'review':additions.length?'ready':'unchanged'};
}
const fingerprint=f=>createHash('sha256').update(JSON.stringify(f)).digest('hex');
function register(app,jira,wrap,learning=createStore()){
  const previews=new Map();
  const read=async key=>(await jira('/rest/api/3/issue/'+encodeURIComponent(key)+'?fields=summary,description,labels,assignee,issuelinks,project,updated,duedate')).fields;
  app.get('/api/label-learning/samples',wrap(async(req,res)=>res.json({samples:await learning.list()})));
  app.post('/api/label-learning/import',wrap(async(req,res)=>{
    let issues=[],nextPageToken;
    const jql='project in (MTG,MC) AND assignee in ('+[...DESIGN].map(id=>'"'+id+'"').join(',')+') AND labels is not EMPTY ORDER BY updated DESC';
    for(let page=0;page<3;page++){const d=await jira('/rest/api/3/search/jql',{method:'POST',body:JSON.stringify({jql,maxResults:100,fields:['summary','description','labels','assignee'],...(nextPageToken?{nextPageToken}:{})})});issues.push(...d.issues);nextPageToken=d.nextPageToken;if(d.isLast||!nextPageToken)break;}
    const added=await learning.ingest(issues.filter(i=>DESIGN.has(i.fields.assignee?.accountId)),true,true);
    res.json({scanned:issues.length,added,hasMore:!!nextPageToken,samples:await learning.list()});
  }));
  app.post('/api/label-learning/review',wrap(async(req,res)=>{
    if(!/^MTG-\d+$|^MC-\d+$/.test(req.body.key||''))return res.status(400).json({message:'Mã task không hợp lệ'});
    try{res.json({sample:await learning.review(req.body.key,req.body.action,req.body.labels)})}catch(e){res.status(400).json({message:e.message})}
  }));
  app.post('/api/auto-labels/preview',wrap(async(req,res)=>{
    const {keys,start,end}=req.body;const mode=req.body.mode==='clear'?'clear':'add';
    const a=new Date(start+'T00:00:00Z'),b=new Date(end+'T00:00:00Z');
    if(!/^\d{4}-\d{2}-\d{2}$/.test(start||'')||!/^\d{4}-\d{2}-\d{2}$/.test(end||'')||!Number.isFinite(+a)||!Number.isFinite(+b)||a.getUTCDay()!==1||b-a!==6*86400000)return res.status(400).json({message:'Auto Labels chỉ quét một tuần từ Thứ 2 đến Chủ nhật.'});
    if(!Array.isArray(keys)||!keys.length||keys.length>100||keys.some(k=>typeof k!=='string'||!/^MTG-\d+$|^MC-\d+$/.test(k)))return res.status(400).json({message:'Chọn từ 1 đến 100 task MTG/MC.'});
    for(const [id,p] of previews)if(Date.now()-p.at>1800000)previews.delete(id);
    const samples=mode==='add'?await learning.list():[];
    const rows=[];let cursor=0;const unique=[...new Set(keys)];
    await Promise.all(Array.from({length:4},async()=>{while(cursor<unique.length){const key=unique[cursor++];try{const fields=await read(key);if(!fields.duedate||fields.duedate<start||fields.duedate>end)throw Error('Task không có hạn trong tuần được chọn');if(!DESIGN.has(fields.assignee?.accountId))throw Error('Task không thuộc Team Design');rows.push({key,summary:fields.summary,assignee:fields.assignee.displayName,existing:fields.labels||[],...(mode==='clear'?{eligible:!!fields.labels?.length,status:fields.labels?.length?'ready':'unchanged',additions:[],reasons:[]}:fields.labels?.length?{eligible:false,status:'labeled',labels:fields.labels,additions:[],reasons:['Task đã có nhãn. Auto Labels chỉ xử lý task chưa có nhãn.']}:suggest(fields,key,samples,classify(fields))),fingerprint:fingerprint(fields)})}catch(e){rows.push({key,summary:key,existing:[],additions:[],eligible:false,status:'error',reasons:[e.message]})}}}));
    const token=randomUUID();previews.set(token,{owner:req.accountId,at:Date.now(),rows,mode,busy:false});res.json({token,start,end,mode,source:require('./team-config').read().rulesUrl,rows:rows.sort((a,b)=>unique.indexOf(a.key)-unique.indexOf(b.key)).map(({fingerprint,...row})=>row)});
  }));
  app.post('/api/auto-labels/choose',wrap(async(req,res)=>{
    const {token,key,labels}=req.body,p=previews.get(token);
    if(!p||p.owner!==req.accountId||p.mode!=='add'||p.busy||Date.now()-p.at>1800000)return res.status(409).json({message:'Hãy quét lại trước khi chọn nhãn.'});
    const row=p.rows.find(r=>r.key===key);
    if(!row||!row.fingerprint||!Array.isArray(labels)||!rules.valid(labels))return res.status(400).json({message:rules.message});
    if(row.existing.length)return res.status(409).json({message:'Task đã có nhãn, không được chỉnh trong Auto Labels.'});
    const chosen=[...new Set(labels)];
    if(chosen.includes('KEY')&&!chosen.some(l=>l!=='KEY'))return res.status(400).json({message:'KEY phải đi kèm một nhãn nhóm chính.'});
    if(row.existing.map(labelKey).filter(l=>GROUPS.includes(l)).some(l=>!chosen.map(labelKey).includes(l)))return res.status(400).json({message:'Task đã có nhãn nhóm khác. Hãy kiểm tra và sửa nhãn hiện tại trên card trước.'});
    row.labels=chosen;row.additions=chosen.filter(l=>!row.existing.some(old=>labelKey(old)===labelKey(l)));row.eligible=!!row.additions.length;row.status=row.eligible?'ready':'unchanged';row.reasons=['Nhãn do bạn chọn trong bản xem trước. Chỉ ghi lên Jira khi bấm Áp dụng.'];
    const {fingerprint,...publicRow}=row;res.json({row:publicRow});
  }));
  app.post('/api/auto-labels/apply',wrap(async(req,res)=>{
    const p=previews.get(req.body.token),keys=req.body.keys;
    if(!p||p.owner!==req.accountId||Date.now()-p.at>1800000)return res.status(409).json({message:'Bản xem trước đã hết hạn. Hãy quét lại.'});
    if(p.busy)return res.status(409).json({message:'Đang cập nhật bản xem trước này.'});
    if(!Array.isArray(keys)||!keys.length||keys.length>100||keys.some(k=>!p.rows.some(r=>r.key===k&&r.eligible)))return res.status(400).json({message:'Danh sách chọn không hợp lệ.'});
    p.busy=true;const results=[];
    try{for(const key of new Set(keys)){const row=p.rows.find(r=>r.key===key);try{const fields=await read(key);if(p.mode!=='clear'&&!rules.valid(row.additions))throw Error(rules.message);if(p.mode!=='clear'&&fields.labels?.length)throw Error('Task đã có nhãn. Quét lại để cập nhật danh sách.');if(!DESIGN.has(fields.assignee?.accountId)||fingerprint(fields)!==row.fingerprint)throw Error('Task đã thay đổi. Quét lại trước khi áp dụng.');await jira('/rest/api/3/issue/'+encodeURIComponent(key),{method:'PUT',body:JSON.stringify({update:{labels:p.mode==='clear'?row.existing.map(remove=>({remove})):row.additions.map(add=>({add}))}})});row.eligible=false;let learningWarning,sampleSaved=false; if(p.mode!=='clear'){try{const savedFields=await read(key);if(!row.additions.every(label=>(savedFields.labels||[]).some(l=>labelKey(l)===labelKey(label))))throw Error('Chưa xác nhận được nhãn mới');await learning.ingest([{key,fields:savedFields}],true,true,true);sampleSaved=true}catch(e){learningWarning='Đã cập nhật Jira nhưng chưa lưu được mẫu: '+e.message}}results.push({key,learningWarning,sampleSaved,ok:true,labels:p.mode==='clear'?[]:row.additions})}catch(e){results.push({key,ok:false,message:e.message})}}}finally{p.busy=false}
    res.json({results});
  }));
}
module.exports={register,classify,SOURCE,isDesign:id=>DESIGN.has(id)};
