'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const {createCredentialCrypto}=require('./desktop/credential-crypto.cjs');
test('Windows retains async encryption and rejects misleading availability',async()=>{
 const c=createCredentialCrypto({isAsyncEncryptionAvailable:async()=>true,encryptStringAsync:async s=>Buffer.from(s),decryptStringAsync:async b=>({result:b.toString()})},'win32');
 assert.equal(await c.available(),true);
 const broken=createCredentialCrypto({isAsyncEncryptionAvailable:async()=>true,encryptStringAsync:async()=>{throw Error('Unavailable')}},'win32');assert.equal(await broken.available(),false);
});
