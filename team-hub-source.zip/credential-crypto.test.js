'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const {createCredentialCrypto}=require('./desktop/credential-crypto.cjs');
test('macOS uses Keychain sync API and proves round-trip before enabling remember',async()=>{
 let calls=0;
 const storage={isEncryptionAvailable:()=>true,encryptString:s=>{calls++;return Buffer.from('encrypted:'+s)},decryptString:b=>b.toString().slice(10),isAsyncEncryptionAvailable:()=>{throw Error('Must not use async on Mac')}};
 const c=createCredentialCrypto(storage,'darwin');assert.equal(await c.available(),true);
 assert.equal(await c.available(),true);assert.equal(calls,1);
 assert.equal(await c.decrypt(await c.encrypt('synthetic-secret')),'synthetic-secret');
});
test('failed Keychain access disables remember, retries later, never stores plaintext',async()=>{
 let unlocked=false;
 const c=createCredentialCrypto({isEncryptionAvailable:()=>unlocked,encryptString:s=>Buffer.from(s),decryptString:b=>b.toString()},'darwin');
 assert.equal(await c.available(),false);unlocked=true;assert.equal(await c.available(),true);
 const denied=createCredentialCrypto({isEncryptionAvailable:()=>true,encryptString:()=>{throw Error('Keychain denied')}},'darwin');
 assert.equal(await denied.available(),false);await assert.rejects(denied.encrypt('synthetic-secret'));
});
test('Windows retains async encryption and rejects misleading availability',async()=>{
 const c=createCredentialCrypto({isAsyncEncryptionAvailable:async()=>true,encryptStringAsync:async s=>Buffer.from(s),decryptStringAsync:async b=>({result:b.toString()})},'win32');
 assert.equal(await c.available(),true);
 const broken=createCredentialCrypto({isAsyncEncryptionAvailable:async()=>true,encryptStringAsync:async()=>{throw Error('Unavailable')}},'win32');assert.equal(await broken.available(),false);
});
