'use strict';
const MAX_FILE = 5 * 1024 * 1024, MAX_EXPANDED = 30 * 1024 * 1024;
function checkArchive(buffer) {
  return new Promise((resolve, reject) => {
    require('yauzl').fromBuffer(buffer, {lazyEntries:true}, (error, zip) => {
      if (error) return reject(Error('File Excel không hợp lệ'));
      let size=0, entries=0;
      zip.on('error', reject);
      zip.on('entry', entry => {
        size+=entry.uncompressedSize;
        if (size>MAX_EXPANDED || ++entries>2000) {zip.close();return reject(Error('File giải nén quá lớn'));}
        zip.readEntry();
      });
      zip.on('end', resolve);
      zip.readEntry();
    });
  });
}
async function readWorkbook(buffer) {
  if (!Buffer.isBuffer(buffer) || buffer.length>MAX_FILE) throw Error('File tối đa 5 MB');
  await checkArchive(buffer);
  // Load only when importing; normal app startup does not parse Excel libraries.
  const ExcelJS=require('exceljs'), workbook=new ExcelJS.Workbook();
  await workbook.xlsx.load(buffer, {ignoreNodes:['drawing','picture','extLst']});
  const sheet=workbook.getWorksheet('Subtasks');
  if (!sheet) throw Error('Không thấy sheet Subtasks. Hãy dùng template của tool.');
  const text=cell=>{
    const v=cell.value;
    if (v==null) return '';
    if (v instanceof Date) return v.toISOString().slice(0,10);
    if (typeof v==='object') {
      if(v.richText)return v.richText.map(part=>part.text).join('').trim();
      if(v.text)return String(v.text).trim();
      if(v.formula||v.sharedFormula)return '';
    }
    return String(v).trim();
  };
  if ([1,2,3,4].map(i=>text(sheet.getCell(1,i)).toLowerCase()).join('|')!=='summary|labels|description|duedate') throw Error('Giữ nguyên 4 cột: Summary, Labels, Description, DueDate');
  const rows=[];
  sheet.eachRow((row,number)=>{
    if(number===1)return;
    const cells=[1,2,3,4].map(i=>row.getCell(i));
    if(cells.every(c=>c.value==null))return;
    if(number>502)throw Error('Dữ liệu vượt dòng 502; hãy đưa task lên đầu sheet');
    if(rows.length>=100)throw Error('Mỗi lần tải tối đa 100 subtask');
    const errors=[];
    if(cells.some(c=>c.value&&typeof c.value==='object'&&('formula' in c.value||'sharedFormula' in c.value)))errors.push('Không dùng công thức; hãy dán giá trị vào ô');
    const [summary,labels,description,duedate]=cells.map(text);
    rows.push({row:number,summary,labels,description,duedate,errors});
  });
  return rows;
}
module.exports={readWorkbook};
