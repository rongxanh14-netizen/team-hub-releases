'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),http=require('node:http');
const {app}=require('./server');
test('local desktop server serves login and animations, rejects remote origins, and protects Jira APIs',async()=>{
  const server=app.listen(0,'127.0.0.1');await new Promise(resolve=>server.once('listening',resolve));
  const request=(route,headers={})=>new Promise((resolve,reject)=>{const req=http.get({hostname:'127.0.0.1',port:server.address().port,path:route,headers:{Host:'127.0.0.1:4850',...headers}},r=>{let body='';r.on('data',b=>body+=b);r.on('end',()=>resolve({status:r.statusCode,body}));});req.on('error',reject);});
  try{const login=await request('/login.html');assert.equal(login.status,200);assert(login.body.includes('loginToken'));assert.equal((await request('/api/tasks')).status,401);assert.equal((await request('/api/tasks',{Origin:'https://untrusted.example'})).status,403);assert.equal((await request('/login.html',{Host:'attacker.example'})).status,403);const css=await request('/style.css');assert.equal(css.status,200);assert(css.body.includes('@keyframes'));assert(css.body.includes('task-dragging'));}finally{await new Promise(resolve=>server.close(resolve));}
});
