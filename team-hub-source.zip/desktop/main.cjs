'use strict';
const {app,BrowserWindow,Menu,dialog,shell,utilityProcess,safeStorage,ipcMain,Notification}=require('electron');
const path=require('node:path');
const {randomBytes}=require('node:crypto');
const {createCredentialVault}=require('./credential-vault.cjs');
const PORT=4851, origin=`http://127.0.0.1:${PORT}`;
let window,backend,quitting=false;
const busy=new Map();
// A second click focuses the existing app instead of launching another server.
if(!app.requestSingleInstanceLock())app.quit();
else {
  app.on('second-instance',()=>{if(window){if(window.isMinimized())window.restore();window.show();window.focus();}});
  app.whenReady().then(start).catch(error=>{dialog.showErrorBox('Team Hub',error.message);app.quit();});
}
function external(url){
  try {const u=new URL(url);if(u.protocol==='https:')void shell.openExternal(u.href).catch(()=>{});}catch{}
}
async function start(){
  process.env.TEAM_HUB_DATA_DIR=path.join(app.getPath('userData'),'data');
  app.setAppUserModelId('vn.tepaylink.teamhub');
  Menu.setApplicationMenu(process.platform==='darwin'?Menu.buildFromTemplate([
    {role:'appMenu'}, {role:'editMenu'}, {role:'viewMenu'}, {role:'windowMenu'}
  ]):null);
  window=new BrowserWindow({width:1440,height:940,minWidth:900,minHeight:640,show:false,title:'Team Hub',backgroundColor:'#0f1011',icon:path.join(__dirname,'assets/icon.png'),autoHideMenuBar:true,webPreferences:{preload:path.join(__dirname,'preload.cjs'),contextIsolation:true,nodeIntegration:false,sandbox:true,webSecurity:true,spellcheck:false,backgroundThrottling:true}});
  window.webContents.session.setPermissionRequestHandler((_webContents,_permission,callback)=>callback(false));
  window.webContents.session.setPermissionCheckHandler(()=>false);
  const desktopKey=randomBytes(32).toString('hex');
  const vault=createCredentialVault({file:path.join(app.getPath('userData'),'remembered-login.bin'),crypto:{
    available:()=>safeStorage.isAsyncEncryptionAvailable(),
    encrypt:value=>safeStorage.encryptStringAsync(value),
    decrypt:async value=>(await safeStorage.decryptStringAsync(value)).result
  }});
  // Bind saved credentials to this app's requests, never to ordinary browser tabs.
  window.webContents.session.webRequest.onBeforeSendHeaders({urls:[origin+'/*']},(details,callback)=>{
    const headers={...details.requestHeaders};
    if(details.webContentsId===window?.webContents.id)headers['X-Team-Hub-Desktop']=desktopKey;
    callback({requestHeaders:headers});
  });
  window.webContents.setWindowOpenHandler(({url})=>{external(url);return {action:'deny'};});
  window.webContents.on('will-navigate',(event,url)=>{if(new URL(url).origin!==origin){event.preventDefault();external(url);}});
  window.webContents.on('will-redirect',(event,url)=>{if(new URL(url).origin!==origin)event.preventDefault();});
  window.on('close',event=>{if(!quitting&&[...busy.values()].some(count=>count>0)){event.preventDefault();dialog.showMessageBoxSync(window,{type:'info',title:'Đang cập nhật Jira',message:'Ứng dụng đang lưu thay đổi hoặc tạo task trên Jira. Vui lòng chờ hoàn tất rồi đóng cửa sổ.',buttons:['Đã hiểu']});}});
  window.on('closed',()=>{window=null;});
  // Keep all renderer animations and GPU acceleration. Jira/Excel run separately.
  backend=utilityProcess.fork(path.join(__dirname,'backend.cjs'),[],{serviceName:'Team Hub Local Server',stdio:'ignore',env:{...process.env,TEAM_HUB_PORT:String(PORT),TEAM_HUB_DATA_DIR:path.join(app.getPath('userData'),'data'),TEAM_HUB_DESKTOP_KEY:desktopKey}});
  backend.on('message',async message=>{
    if(message.type==='busy')busy.set(message.scope,message.count);
    if(message.type==='credential-request'&&['available','has','read','save','clear'].includes(message.method)){
      try{const value=await vault[message.method](message.arg);backend.postMessage({type:'credential-result',id:message.id,value});}
      catch{backend.postMessage({type:'credential-result',id:message.id,error:'Không truy cập được kho đăng nhập của hệ điều hành.'});}
    }
  });
  await new Promise((resolve,reject)=>{
    const timer=setTimeout(()=>reject(Error('Khởi động quá lâu. Hãy mở lại Team Hub.')),20000);
    backend.on('message',message=>{if(message.type==='ready'){clearTimeout(timer);resolve();}else if(message.type==='error'){clearTimeout(timer);reject(Error(message.message||'Không thể khởi động máy chủ local'));}});
    backend.once('exit',code=>{clearTimeout(timer);reject(Error('Máy chủ local đã dừng ('+code+').'));});
  });
  backend.on('exit',()=>{if(!quitting){dialog.showErrorBox('Team Hub','Kết nối local đã dừng. Đóng và mở lại ứng dụng để tiếp tục.');app.quit();}});
  await window.loadURL(origin+'/#team/design/dashboard');
  window.show();
  // Main-process clock continues while the window is minimized.
  const syncClock=setInterval(()=>{if(window&&!window.isDestroyed()&&![...busy.values()].some(n=>n>0))window.webContents.send('hub-auto-sync');},30000);
  syncClock.unref();window.once('closed',()=>clearInterval(syncClock));
  const trusted=event=>event.sender===window?.webContents&&event.senderFrame===window.webContents.mainFrame&&new URL(event.senderFrame.url).origin===origin;
  const sendNotification=require('./notifications.cjs').createNotifications({Notification,icon:path.join(__dirname,'assets/icon.png'),focus:()=>{if(window&&!window.isDestroyed()){if(window.isMinimized())window.restore();window.show();window.focus()}}});
  ipcMain.handle('hub-notify',(event,payload)=>{if(!trusted(event))throw Error('Không được phép');return sendNotification(payload)});
  ipcMain.handle('hub-save-report',async(event,payload)=>{if(!trusted(event))throw Error('Không được phép');if(typeof payload?.html!=='string'||Buffer.byteLength(payload.html)>8000000||!/^Team-Hub-[A-Za-z]+-[0-9-]+\.html$/.test(payload.filename||''))throw Error('Report không hợp lệ');const result=await dialog.showSaveDialog(window,{title:'Lưu report biểu đồ',defaultPath:payload.filename,filters:[{name:'HTML report',extensions:['html']}]});if(result.canceled||!result.filePath)return{saved:false};await require('node:fs/promises').writeFile(result.filePath,payload.html,'utf8');return{saved:true};});
  const {createUpdater}=require('./updater.cjs');
  const updatesEnabled=app.isPackaged&&!process.env.PORTABLE_EXECUTABLE_FILE&&!require('../package.json').localPreview;
  const updates=createUpdater({updater:updatesEnabled?require('electron-updater').autoUpdater:null,version:app.getVersion(),enabled:updatesEnabled,
    notify:s=>{if(window&&!window.isDestroyed())window.webContents.send('hub-update-state',s)},busy:()=>[...busy.values()].some(n=>n>0),
    confirmInstall:async()=>{const r=await dialog.showMessageBox(window,{type:'question',buttons:['Cập nhật','Để sau'],defaultId:1,cancelId:1,title:'Cập nhật Team Hub',message:'Lưu các nội dung đang nhập trước khi cập nhật.',detail:'App sẽ đóng và mở lại. Dữ liệu chưa gửi từ bảng template hoặc form đang nhập sẽ không được giữ.'});return r.response===0},
    prepareQuit:async()=>{await window.webContents.session.cookies.flushStore();quitting=true;backend?.kill();}
  });
  ipcMain.handle('hub-update',(event,action)=>{if(!trusted(event))throw Error('Không được phép');if(!['status','check','install'].includes(action))throw Error('Thao tác không hợp lệ');return updates[action]()});
  ipcMain.handle('hub-import-config',async event=>{if(!trusted(event))throw Error('Không được phép');if([...busy.values()].some(n=>n>0))return{message:'Chờ thao tác Jira hoàn tất trước khi nhập cấu hình.'};const result=await dialog.showOpenDialog(window,{title:'Chọn cấu hình team nội bộ',properties:['openFile'],filters:[{name:'Cấu hình Team Hub',extensions:['json']}]});if(result.canceled)return{message:''};try{const fs=require('node:fs');if(fs.statSync(result.filePaths[0]).size>200000)throw Error('File cấu hình quá lớn.');require('../team-config').save(JSON.parse(fs.readFileSync(result.filePaths[0],'utf8')));return{ok:true,message:'Đã nhập cấu hình.'}}catch{return{message:'File cấu hình không hợp lệ. Chọn file cấu hình team được cung cấp.'}}});
  if(updatesEnabled){setTimeout(()=>void updates.check(),15000).unref();setInterval(()=>void updates.check(),6*60*60*1000).unref();}
}
app.on('window-all-closed',()=>app.quit());
app.on('before-quit',event=>{
  if(quitting)return;
  event.preventDefault();quitting=true;
  // Persist the opaque remember cookie before shutting down Chromium.
  const {session}=require('electron');
  Promise.resolve(app.isReady()?session.defaultSession.cookies.flushStore():undefined).catch(()=>{}).finally(()=>{backend?.kill();app.quit();});
});
