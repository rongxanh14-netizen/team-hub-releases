'use strict';
const {contextBridge,ipcRenderer,webFrame}=require('electron');
contextBridge.exposeInMainWorld('teamHubDesktop',{
 onAutoSync:callback=>{const listener=()=>callback();ipcRenderer.on('hub-auto-sync',listener);return()=>ipcRenderer.removeListener('hub-auto-sync',listener);},
 notify:payload=>ipcRenderer.invoke('hub-notify',payload),saveReport:payload=>ipcRenderer.invoke('hub-save-report',payload),
 setScale:percent=>webFrame.setZoomFactor(Math.max(75,Math.min(150,Number(percent)||100))/100),
 status:()=>ipcRenderer.invoke('hub-update','status'),check:()=>ipcRenderer.invoke('hub-update','check'),install:()=>ipcRenderer.invoke('hub-update','install'),importConfig:()=>ipcRenderer.invoke('hub-import-config'),
 onUpdate:callback=>{const listener=(_event,state)=>callback(state);ipcRenderer.on('hub-update-state',listener);return()=>ipcRenderer.removeListener('hub-update-state',listener);}
});
