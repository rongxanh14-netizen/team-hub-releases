'use strict';
function createNotifications({Notification,focus,icon}){
 const active=new Set();
 return async payload=>{
  if(!payload||typeof payload.title!=='string'||typeof payload.body!=='string'||payload.title.length>120||payload.body.length>1500)return false;
  if(!Notification.isSupported())return false;
  return new Promise(resolve=>{
   let settled=false,timer;const done=value=>{if(settled)return;settled=true;clearTimeout(timer);resolve(value)};
   try{const note=new Notification({title:payload.title,body:payload.body,icon,silent:false});active.add(note);note.once('show',()=>done(true));note.once('failed',()=>{active.delete(note);done(false)});note.once('close',()=>active.delete(note));note.once('click',()=>{active.delete(note);focus()});timer=setTimeout(()=>{active.delete(note);done(false)},5000);note.show();}catch{done(false)}
  });
 };
}
module.exports={createNotifications};
