'use strict';
function createUpdater({updater,version,enabled,notify,busy,confirmInstall,prepareQuit}){
 let state={version,phase:enabled?'idle':'unavailable',nextVersion:'',percent:0,message:enabled?'Tự kiểm tra khi mở app và mỗi 6 giờ.':'Auto update dùng trong bản cài đặt Team Hub.'};
 if(!enabled)return {check:async()=>({...state}),install:async()=>({...state}),status:()=>({...state})};
 let checking=false,installing=false;
 const set=patch=>{state={...state,...patch};notify({...state});};
 updater.autoDownload=true;updater.autoInstallOnAppQuit=false;updater.allowPrerelease=false;updater.allowDowngrade=false;
 updater.on('checking-for-update',()=>set({phase:'checking',message:'Đang kiểm tra phiên bản mới…'}));
 updater.on('update-available',info=>set({phase:'downloading',nextVersion:info.version,percent:0,message:'Đang tải bản cập nhật…'}));
 updater.on('download-progress',p=>set({phase:'downloading',percent:Math.max(0,Math.min(100,Math.round(p.percent)))}));
 updater.on('update-not-available',()=>set({phase:'current',message:'Bạn đang dùng phiên bản mới nhất.'}));
 updater.on('update-downloaded',info=>set({phase:'ready',nextVersion:info.version,percent:100,message:'Đã tải xong. Khởi động lại khi bạn sẵn sàng.'}));
 updater.on('error',()=>set({phase:'error',message:'Chưa cập nhật được. Kiểm tra kết nối rồi thử lại.'}));
 async function check(){if(!enabled||checking||installing||['downloading','ready'].includes(state.phase))return{...state};checking=true;try{await updater.checkForUpdates()}catch{set({phase:'error',message:'Chưa kết nối được nơi phát hành. Thử lại sau.'})}finally{checking=false}return{...state};}
 async function install(){if(!enabled||state.phase!=='ready'||installing)return{...state};if(busy())return{...state,message:'Đang lưu Jira hoặc tạo task. Chờ hoàn tất rồi cập nhật.'};if(!await confirmInstall())return{...state};if(busy())return{...state,message:'Đang lưu Jira. Chờ hoàn tất rồi cập nhật.'};installing=true;try{await prepareQuit();updater.quitAndInstall(false,true)}catch{installing=false;set({phase:'error',message:'Chưa khởi động lại được. Vui lòng thử lại.'})}return{...state};}
 return{check,install,status:()=>({...state})};
}
module.exports={createUpdater};
