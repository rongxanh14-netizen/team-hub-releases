'use strict';
// Electron 44: use the established Keychain API on macOS. The async
// availability flag alone does not guarantee that encryption will succeed.
function createCredentialCrypto(safeStorage,platform=process.platform){
  const legacyMac=platform==='darwin'&&typeof safeStorage.encryptString==='function';
  const encrypt=async value=>legacyMac?safeStorage.encryptString(value):safeStorage.encryptStringAsync(value);
  const decrypt=async value=>legacyMac?safeStorage.decryptString(value):(await safeStorage.decryptStringAsync(value)).result;
  let verified=false,checking;
  async function available(){
    if(verified)return true;
    if(checking)return checking;
    checking=(async()=>{
      try{
        const ready=legacyMac?safeStorage.isEncryptionAvailable():await safeStorage.isAsyncEncryptionAvailable();
        if(!ready)return false;
        const probe='Team Hub credential storage check';
        verified=await decrypt(await encrypt(probe))===probe;
        return verified;
      }catch{return false;}
    })();
    try{return await checking;}finally{checking=null;}
  }
  return {available,encrypt,decrypt};
}
module.exports={createCredentialCrypto};
