'use strict';
const fs=require('node:fs/promises'),path=require('node:path'),{randomBytes}=require('node:crypto');
const REMEMBER_DAYS=30;
function createCredentialVault({file,crypto,clock=Date.now}){
  let queue=Promise.resolve();
  const serialize=fn=>{const job=queue.then(fn);queue=job.catch(()=>{});return job;};
  const available=async()=>Boolean(await crypto.available());
  async function readSaved(){
    let bytes;try{bytes=await fs.readFile(file);}catch(e){if(e.code==='ENOENT')return null;throw e;}
    if(!await available())throw Error('Hệ điều hành chưa sẵn sàng mở kho đăng nhập.');
    try{
      const saved=JSON.parse(await crypto.decrypt(bytes));
      if(saved.version!==1||!/^[a-f0-9]{64}$/.test(saved.deviceId)||!Number.isFinite(saved.expires)||!saved.email||!saved.token)return null;
      return saved;
    }catch{return null;}
  }
  async function read(deviceId){
    const saved=await readSaved();
    if(saved&&saved.expires<=clock()){await fs.rm(file,{force:true});return null;}
    return saved&&saved.deviceId===deviceId?saved:null;
  }
  return {
    available,
    has:deviceId=>serialize(async()=>Boolean(await read(deviceId))),
    read:deviceId=>serialize(()=>read(deviceId)),
    save:credentials=>serialize(async()=>{
      if(!await available())throw Error('Hệ điều hành chưa sẵn sàng mã hóa thông tin đăng nhập.');
      if(!/^[^\s@]+@tepaylink\.com\.vn$/.test(credentials.email)||!credentials.token||credentials.token.length>4096||!/^[a-f0-9]{64}$/.test(credentials.deviceId))throw Error('Thông tin ghi nhớ không hợp lệ.');
      const saved={version:1,email:credentials.email,token:credentials.token,deviceId:credentials.deviceId,expires:clock()+REMEMBER_DAYS*86400000};
      const encrypted=await crypto.encrypt(JSON.stringify(saved));
      const temp=file+'.'+randomBytes(6).toString('hex')+'.tmp';
      await fs.mkdir(path.dirname(file),{recursive:true});
      try{await fs.writeFile(temp,encrypted,{mode:0o600});await fs.rename(temp,file);}finally{await fs.rm(temp,{force:true}).catch(()=>{});}
      return {expires:saved.expires};
    }),
    clear:deviceId=>serialize(async()=>{
      // A trusted desktop logout also clears an orphaned save after cookies were reset.
      if(!deviceId){await fs.rm(file,{force:true});return true;}
      const saved=await readSaved();
      if(!saved||saved.deviceId===deviceId)await fs.rm(file,{force:true});
      return true;
    })
  };
}
module.exports={createCredentialVault,REMEMBER_DAYS};
