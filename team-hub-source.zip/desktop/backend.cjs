'use strict';
const {createCredentialClient}=require('./credential-client.cjs');
require('../account-auth').configureRemember({vault:createCredentialClient(process.parentPort),desktopKey:process.env.TEAM_HUB_DESKTOP_KEY});
const {startServer}=require('../server');
startServer().then(server=>{
  process.parentPort.postMessage({type:'ready',port:server.address().port});
}).catch(error=>{
  process.parentPort.postMessage({type:'error',message:error.code==='EADDRINUSE'?'Cổng 4851 đang được ứng dụng khác sử dụng. Đóng bản Team Hub đang chạy rồi mở lại.':'Không thể khởi động Team Hub: '+error.message});
  process.exitCode=1;
});
