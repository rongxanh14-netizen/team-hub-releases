'use strict';
const {spawn}=require('node:child_process');
const {randomBytes,createCipheriv,createDecipheriv}=require('node:crypto');
const MAGIC=Buffer.from('THK2');
// Use Apple's signed security tool rather than the unsigned Electron app's
// OSCrypt identity. Secrets travel over pipes, never command-line arguments.
function runSecurity(args,input){
 return new Promise((resolve,reject)=>{
  const child=spawn('/usr/bin/security',args,{stdio:['pipe','pipe','pipe']});
  let stdout='',size=0,settled=false;
  const finish=(error,value)=>{if(settled)return;settled=true;clearTimeout(timer);error?reject(error):resolve(value)};
  const timer=setTimeout(()=>{child.kill();finish(Error('Keychain timed out'));},90000);
  child.stdout.on('data',b=>{size+=b.length;if(size>16384){child.kill();finish(Error('Invalid Keychain response'))}else stdout+=b});
  child.stderr.on('data',()=>{}); // Never expose security tool output in logs/errors.
  child.on('error',()=>finish(Error('Cannot open Keychain')));
  child.stdin.on('error',()=>{});
  child.on('close',code=>finish(code===0?null:Object.assign(Error('Keychain access failed'),{code}),stdout));
  child.stdin.end(input||'');
 });
}
function createMacKeychainCrypto({legacyDecrypt,service='vn.tepaylink.teamhub.credentials.v2',keychain='',run=runSecurity}={}){
 if(!/^[\w.-]+$/.test(service)||/[\r\n\0]/.test(keychain))throw Error('Invalid Keychain identity');
 const suffix=keychain?[keychain]:[];
 const readKey=async()=>{
  const value=(await run(['find-generic-password','-a','encryption-key','-s',service,'-w',...suffix])).trim();
  if(!/^[a-f0-9]{64}$/.test(value))throw Error('Invalid Keychain key');
  return Buffer.from(value,'hex');
 };
 async function key(create){
  try{return await readKey()}catch(e){if(!create||e.code!==44)throw e}
  const secret=randomBytes(32).toString('hex');
  const quote=s=>'"'+s.replace(/\\/g,'\\\\').replace(/"/g,'\\"')+'"';
  // Do not use -A (all apps), -U (overwrite), or put a secret in argv.
  await run(['-i'],`add-generic-password -a encryption-key -s ${service} -w ${secret} -T /usr/bin/security${keychain?' '+quote(keychain):''}\n`);
  return readKey(); // Also catches errors from interactive commands and races.
 }
 return {
  available:async()=>true,
  encrypt:async value=>{
   const k=await key(true),iv=randomBytes(12);
   try{const cipher=createCipheriv('aes-256-gcm',k,iv),data=Buffer.concat([cipher.update(value,'utf8'),cipher.final()]);return Buffer.concat([MAGIC,iv,cipher.getAuthTag(),data])}finally{k.fill(0)}
  },
  decrypt:async bytes=>{
   if(!bytes.subarray(0,4).equals(MAGIC)){if(legacyDecrypt)return legacyDecrypt(bytes);throw Error('Unknown saved login format')}
   if(bytes.length<32)throw Error('Invalid saved login');
   const k=await key(false);
   try{const cipher=createDecipheriv('aes-256-gcm',k,bytes.subarray(4,16));cipher.setAuthTag(bytes.subarray(16,32));return Buffer.concat([cipher.update(bytes.subarray(32)),cipher.final()]).toString('utf8')}finally{k.fill(0)}
  }
 };
}
module.exports={createMacKeychainCrypto,runSecurity};
