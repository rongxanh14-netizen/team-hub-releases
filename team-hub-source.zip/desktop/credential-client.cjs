'use strict';
const {randomUUID}=require('node:crypto');
function createCredentialClient(port){
  const pending=new Map();
  port.on('message',({data})=>{
    if(data?.type!=='credential-result')return;
    const job=pending.get(data.id);if(!job)return;
    pending.delete(data.id);clearTimeout(job.timer);
    data.error?job.reject(Error(data.error)):job.resolve(data.value);
  });
  const call=(method,arg)=>new Promise((resolve,reject)=>{
    const id=randomUUID();
    const timer=setTimeout(()=>{pending.delete(id);reject(Error('Không truy cập được thông tin đăng nhập đã lưu.'));},120000);
    pending.set(id,{resolve,reject,timer});port.postMessage({type:'credential-request',id,method,arg});
  });
  return Object.fromEntries(['available','has','read','save','clear'].map(method=>[method,arg=>call(method,arg)]));
}
module.exports={createCredentialClient};
